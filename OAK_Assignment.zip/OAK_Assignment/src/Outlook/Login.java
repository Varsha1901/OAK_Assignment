package Outlook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Login 
{

	WebDriver driver;
	WebDriverWait wait;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	XSSFCell cell;
	
	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) throws Exception
	{
		/*//Check if parameter passed from TestNG is 'firefox'
		if(browser.equalsIgnoreCase("Firefox")){
			//create firefox instance
			System.setProperty("webdriver.gecko.driver", ".\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.get("https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
			//driver.manage().window().maximize();

			wait = new WebDriverWait(driver,30);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}*/
		//Check if parameter passed as 'chrome'
		 if(browser.equalsIgnoreCase("chrome")){
			//set path to chromedriver.exe
			System.setProperty("webdriver.chrome.driver",".\\chromedriver.exe");
			//create chrome instance
			driver = new ChromeDriver();
			driver.get("https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
			//driver.manage().window().maximize();

			wait = new WebDriverWait(driver,30);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		}
		else{
			//If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
	}

	@Test
	public void Login() throws Throwable
	{
		//Import excel sheet
		File source = new File(".\\TestData.xlsx");

		//Load the file
		FileInputStream fileIn = new FileInputStream(source);

		//Load the workbook
		workbook = new XSSFWorkbook(fileIn);

		//Load the sheet in which data is stored
		sheet = workbook.getSheetAt(0);
		

		for(int i = 1; i<2; i++ )
		{
			//import data for Email
			cell = sheet.getRow(i).getCell(1);
			driver.findElement(By.id("identifierId")).sendKeys(cell.getStringCellValue());

			driver.findElement(By.id("identifierNext")).click();

			//import data for password
			cell = sheet.getRow(i).getCell(2);
			driver.findElement(By.name("password")).sendKeys(cell.getStringCellValue());

			driver.findElement(By.id("passwordNext")).click();

			driver.quit();

		}

	}

}
